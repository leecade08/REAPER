1. Open Chrome
2. Click the three dots in the top right corner of Chrome
3. Click more tools, then extensions
4. Click load unpacked, then click Legacy Trading Bot
5. Go to roblox.com, and the features should load!